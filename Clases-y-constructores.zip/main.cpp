#include <iostream>
#include "figura.h"

using namespace std;
int main() {
  figura cuadrado(4,2);
  figura* triangulo=new figura(3,3);

  cuadrado.calcular();  
  triangulo->calcular();
  delete triangulo;
  
  
  
  
}