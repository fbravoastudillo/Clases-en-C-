//def metodos
#include <iostream>
#include "figura.h"
#include <math.h>
using namespace std;

figura::figura(int lados , int tamano_lados){
this->cantidad_lados=lados;
  this ->tamano_lados=tamano_lados;
    cout<<"Se ha creado un objeto de tipo figura de "<<tamano_lados<<" y de lados "<<lados<<endl;
}
figura::~figura(){

  cout<<"Se ha destruido el objeto"<<endl;
}
float figura::calcular(){
  if(this->cantidad_lados==3){
    float pot=tamano_lados*tamano_lados;
    cout<<"Potencia de A2: "<<pot<<endl;
    float op=(pot-pot/2);
    cout<<"Contenido de operacion: "<<op<<endl;
    float h=sqrt(op);
    cout<<"La altura es: "<<h<<endl;
    float area=(h*tamano_lados)/2;
    cout<<"El area resultante del triangulo es: "<<area<<endl;
    return 0;
    
  }
  if(this->cantidad_lados==4){
    int area =tamano_lados*tamano_lados;
    cout<<"El area resultante del cuadrado es: "<<area<<endl;
  }
  return 0;
}


