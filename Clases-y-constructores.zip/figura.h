//declaracion clase
class figura{
public:
int cantidad_lados,tamano_lados;
figura(int lados , int tamano_lados);//ctor
~figura();//dtor
float calcular();
};